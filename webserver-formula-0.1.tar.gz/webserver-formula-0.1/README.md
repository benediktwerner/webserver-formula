# Example webserver Salt Formula
Exapmle webserver Salt Formula for SUSE Manager
